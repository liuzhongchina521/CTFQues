#!/bin/bash

timeout --foreground 1200 ./qemu-system-x86_64  \
	-initrd ./initramfs.img -kernel ./kernel-guest \
	-L pc-bios -append "console=ttyS0 loglevel=3 oops=panic panic=1 kaslr" -nographic  \
	-drive file=./nvme.raw,format=raw,if=none,id=Dxx -device nvme,drive=Dxx,serial=1234
